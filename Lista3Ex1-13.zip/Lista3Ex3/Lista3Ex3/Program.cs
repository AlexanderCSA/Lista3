﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char sexo;
            Console.WriteLine("\nLista 3 Exercício 3\n");
            do
            {
                Console.WriteLine("Digite o Sexo em Letra Maiúscula: \n\nFeminino (F) \nMasculino (M) ");
                sexo = char.Parse(Console.ReadLine());
            } while (sexo != 'M' && sexo != 'F');
        }
    }
}
