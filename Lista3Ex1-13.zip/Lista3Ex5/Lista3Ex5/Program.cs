﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val = 0;
            double res = 0;
            int cont = 0;
            Console.WriteLine("\nLista 3 Exercício 5 \n");
            do
            {
                Console.WriteLine("Digtite um Valor:");
                val = double.Parse(Console.ReadLine());
            } while (val < 0);
            do
            {
                cont++;
                res = val * cont;
                Console.WriteLine("{0} x {1} = {2}", cont, val, res);
            } while (cont < 10);
        }
    }
}
