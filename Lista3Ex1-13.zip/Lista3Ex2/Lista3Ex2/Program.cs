﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1 = 0;
            double valor2 = 0;

            Console.WriteLine("\nLista 3 Exercício 2 \n");

            Console.Write("Digite o Primeiro Valor: ");
            valor1 = double.Parse(Console.ReadLine());
            do
            {
                Console.Write("Digite o Segundo Valor: ");
                valor2 = double.Parse(Console.ReadLine());
            } while (valor2 <= valor1);
        }
    }
}
