﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val;
            double maior = 0;
            double cont = 0;
            double soma = 0;
            double med;
            Console.WriteLine("\nLista 3 Exercício 10 \n");
            do
            {
                cont++;
                Console.Write("Digite o {0}º Valor: ", cont);
                val = double.Parse(Console.ReadLine());
                while (val < 0)
                {
                    Console.WriteLine("Erro!");
                    Console.Write("Informe o {0}º Valor Novamente: ", cont);
                    val = double.Parse(Console.ReadLine());
                }
                if (val > maior)
                {
                    maior = val;
                }
                soma = soma + val;
            } while (cont < 10);
            
            med = soma / 10;
            Console.WriteLine("");
            Console.WriteLine("Maior Valor: {0}", maior);
            Console.WriteLine("Soma dos Valores: {0}", soma);
            Console.WriteLine("Média dos Valores: {0}", med);
        }
    }
}
