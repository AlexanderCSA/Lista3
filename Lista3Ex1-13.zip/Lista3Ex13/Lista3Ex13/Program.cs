﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char resp;
            Console.WriteLine("\nLista 3 Exercício 13 da \n");
            do
            {
                double val = 0;
                double cont = 1;
                double fat = 1;
                Console.WriteLine("\nDigite um Valor:");
                val = double.Parse(Console.ReadLine());
                while (val < 0)
                {
                    Console.WriteLine("Erro!");
                    Console.WriteLine("Informe esse Valor Novamente: ");
                    val = double.Parse(Console.ReadLine());
                }
                do
                {
                    fat = fat * cont;
                    cont++;
                }
                while (cont <= val);
                Console.WriteLine("{0}! = {1}", val, fat);
                Console.WriteLine("");
                do
                {
                    Console.WriteLine("Executar Novamente (S) para Sim, (N) para Não?");
                    resp = char.Parse(Console.ReadLine());
                } while (resp != 'S' && resp != 'N');
            } while (resp != 'N');
        }
    }
}
