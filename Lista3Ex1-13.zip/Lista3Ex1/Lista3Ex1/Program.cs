﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor = 0;
            Console.WriteLine("\nLista 3 Exercício 1 \n");
            do
            {
                Console.Write("Digite um Número: ");
                valor = double.Parse(Console.ReadLine());
            } while (valor < 0);
        }
    }
}
