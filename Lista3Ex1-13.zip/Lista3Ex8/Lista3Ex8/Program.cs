﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double cont = 0;
            double res = 0;
            Console.WriteLine("\nLista 3 Exercício 8 \n");
            do
            {
                cont++;
                res = res + cont;
            } while (cont < 100);
            Console.WriteLine("A Soma dos Números Inteiros Positivos no Itervalo de 1 a 100 é: {0}", res);
        }
    }
}
